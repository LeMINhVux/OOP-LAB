package hust.soict.hedspi.aims;

//import hust.soict.hedspi.aims.media.Media;
//import hust.soict.hedspi.aims.media.disc.DigitalVideoDisc;
//import hust.soict.hedspi.aims.order.Order;

public class DiskTest {

	public static void main(String[] args) {
//		 Make an order
//		Order anOrder = new Order();
//		DigitalVideoDisc dvd1 = new DigitalVideoDisc("d1","The Lion King",87,19.95f);
//		dvd1.setCategory("Animation");
//		dvd1.setDirector("Roger Allers");
//		anOrder.addMedia(dvd1);
//		DigitalVideoDisc dvd2 = new DigitalVideoDisc("d2","Star Wars",124,24.95f);
//		dvd2.setCategory("Science Fiction");
//		dvd2.setDirector("George Lucas");
//		anOrder.addMedia(dvd2);
		// Test for seacrh method
		// System.out.println(dvd1.search("Lion"));
		// Test get an item free
//		Media luckyItem = anOrder.getALuckyItem();
//		System.out.println("_*_THE LUCKY ITEM IS " + luckyItem.getTitle() + "_*_");
//		anOrder.print();
	}

}