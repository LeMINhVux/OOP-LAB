package hust.soict.hedspi.aims.media.disc;

import hust.soict.hedspi.aims.exceptions.PlayerException;

public interface Playable {
    public void play() throws PlayerException;
}
