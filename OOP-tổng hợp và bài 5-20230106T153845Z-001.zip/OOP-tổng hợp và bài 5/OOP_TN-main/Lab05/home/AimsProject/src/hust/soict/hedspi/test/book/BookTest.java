package hust.soict.hedspi.test.book;

import hust.soict.hedspi.aims.media.book.Book;

public class BookTest {

	public static void main(String[] args) {
//		Book b1 = new Book("DF3", "Poem", 72);
//		b1.setContent("I think there is someone praying for someone I can slightly hear the love poem that was written in silence I wish it flies to you and arrives to your place in time I’ll be there behind you who walk alone Singing till the end, this song would be endless Listen carefully for a second I will sing for you who walk on a long night \n");
//		System.out.println(b1.getContent());
//		System.out.println(b1.contentTokens);
//		System.out.println(b1.wordFrequency);
//		System.out.println("========================================");
//		System.out.println(b1.toString());
	}

}