package hust.soict.hedspi.aims.exceptions;

public class PlayerException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	 public PlayerException() {
	        // TODO Auto-generated constructor stub
	    }

	public PlayerException(String message) {
	        super(message);
	        // TODO Auto-generated constructor stub
	    }

	public PlayerException(Throwable cause) {
	        super(cause);
	        // TODO Auto-generated constructor stub
	    }

	public PlayerException(String message, Throwable cause) {
	        super(message, cause);
	        // TODO Auto-generated constructor stub
	    }
}