Bài tập môn Thực hành Hướng Đối Tượng 

- Lab 01 do chưa tổ chức theo file nên là tới Lab 02 mới tổ chức lại, khi bấm vào Lab01 sẽ thấy file cũ và file mới ko khác gì nhau, nên ko phải là Lab 01 tới tận Lab 02 mới nộp 
Thanks

- Lab03 lỗi hiển thị, bấm mở lab03 sẽ thấy thời gian up file đúng 
, ngày 2/1 thêm comment mà nó load hết bài @@ ko hiểu vì sao 
